package com.org.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table
public class Transaction1 extends Account{

	private double amount;
	private String status;
	
	public Transaction1() {
		// TODO Auto-generated constructor stub
	}

	public Transaction1(String cardNumber, Date date, double amount, String status) {
		super(cardNumber, date);
		this.amount = amount;
		this.status = status;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Transaction1 [amount=" + amount + ", status=" + status + "]";
	}
}
