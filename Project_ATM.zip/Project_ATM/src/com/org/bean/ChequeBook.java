package com.org.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table
public class ChequeBook extends Account{

	private String status;
	
	public ChequeBook() {
		// TODO Auto-generated constructor stub
	}

	public ChequeBook(String cardNumber, Date date, String status) {
		super(cardNumber, date);
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ChequeBook [status=" + status + "]";
	}
}
