package com.org.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Account {

	@Id
	private String cardNumber;
	private Date date;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(String cardNumber, Date date) {
		super();
		this.cardNumber = cardNumber;
		this.date = date;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Account [cardNumber=" + cardNumber + ", date=" + date + "]";
	}
}
